import Link from "next/link";
import { NEGOCIO, CARGADORES, ADAPTADORES, TARIFAS, formatoCOP } from "@/lib/config";

export default function Home() {
  return (
    <main className="min-h-screen">
      {/* HERO */}
      <section className="bg-[var(--ink)] text-white">
        <div className="mx-auto max-w-3xl px-5 py-14 sm:py-20">
          <div className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-sm text-white/80">
            <span className="text-[var(--verde)]">⚡</span> Carga eléctrica · San Joaquín, Cali
          </div>
          <h1 className="mt-5 text-4xl font-extrabold leading-tight sm:text-5xl">
            Reserva tu carga en <span className="text-[var(--verde)]">{NEGOCIO.nombre}</span>
          </h1>
          <p className="mt-4 max-w-xl text-lg text-white/70">
            {NEGOCIO.subtitulo}. Reserva tu horario en un minuto y llega con la seguridad de que el
            cargador es tuyo. Servicio disponible las 24 horas.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/reservar"
              className="inline-flex items-center justify-center rounded-2xl bg-[var(--verde)] px-7 py-4 text-base font-semibold text-[var(--ink)] transition hover:bg-[var(--verde-dark)] hover:text-white"
            >
              Reservar mi carga
            </Link>
            <a
              href={NEGOCIO.mapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center rounded-2xl border border-white/20 px-7 py-4 text-base font-semibold text-white transition hover:bg-white/10"
            >
              📍 Cómo llegar
            </a>
          </div>
        </div>
      </section>

      {/* INFO DEL CARGADOR */}
      <section className="mx-auto max-w-3xl px-5 py-12">
        <div className="grid gap-4 sm:grid-cols-2">
          <InfoCard titulo="Tipo de cargador" valor="J1772 (Tipo 1)" detalle="Estándar para la mayoría de EV." />
          <InfoCard
            titulo="Adaptadores disponibles"
            valor={ADAPTADORES.join(" · ")}
            detalle="Sin costo. Cargamos BYD, Kia, Nissan, Chevrolet, JAC y más."
          />
          <InfoCard titulo="Potencia" valor={NEGOCIO.potencia} detalle="Es carga AC: las sesiones toman varias horas." />
          <InfoCard
            titulo="Cargadores"
            valor={`${CARGADORES.length} disponibles`}
            detalle={CARGADORES.map((c) => `${c.id}: ${c.direccion}`).join(" · ")}
          />
        </div>

        {/* TARIFA */}
        <div className="mt-6 rounded-2xl border border-black/5 bg-white p-5">
          <h2 className="text-lg font-bold">Tarifa por kWh</h2>
          <p className="mt-1 text-sm text-black/55">
            El pago es en el sitio: {NEGOCIO.pago.toLowerCase()}
          </p>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
            {TARIFAS.filter((t, i, arr) => arr.findIndex((x) => x.etiqueta === t.etiqueta) === i).map((t) => (
              <div key={t.etiqueta} className="rounded-xl bg-[var(--crema)] px-3 py-2 text-sm">
                <div className="font-semibold">{formatoCOP(t.valor)}/kWh</div>
                <div className="text-black/50">{t.etiqueta}</div>
              </div>
            ))}
          </div>
        </div>

        {/* INSTRUCCIONES */}
        <div className="mt-6 rounded-2xl border border-black/5 bg-white p-5">
          <h2 className="text-lg font-bold">Cómo funciona</h2>
          <ol className="mt-3 space-y-3">
            {[
              "Reserva tu fecha y hora aquí mismo.",
              "Llega al punto a la hora reservada.",
              "Conecta tu vehículo: la carga inicia automáticamente.",
            ].map((paso, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="mt-0.5 flex h-6 w-6 flex-none items-center justify-center rounded-full bg-[var(--verde)] text-sm font-bold text-[var(--ink)]">
                  {i + 1}
                </span>
                <span className="text-black/75">{paso}</span>
              </li>
            ))}
          </ol>
        </div>

        <div className="mt-8 text-center">
          <Link
            href="/reservar"
            className="inline-flex items-center justify-center rounded-2xl bg-[var(--ink)] px-7 py-4 text-base font-semibold text-white transition hover:opacity-90"
          >
            Reservar mi carga
          </Link>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="border-t border-black/5 bg-white">
        <div className="mx-auto max-w-3xl px-5 py-8 text-sm text-black/60">
          <p className="font-semibold text-black/80">{NEGOCIO.nombre}</p>
          <p className="mt-1">WhatsApp: {NEGOCIO.contacto.whatsapp} · {NEGOCIO.contacto.correo}</p>
          <p className="mt-1">{CARGADORES.map((c) => c.direccion).join(" — ")}</p>
        </div>
      </footer>
    </main>
  );
}

function InfoCard({ titulo, valor, detalle }: { titulo: string; valor: string; detalle: string }) {
  return (
    <div className="rounded-2xl border border-black/5 bg-white p-5">
      <div className="text-sm font-medium text-black/45">{titulo}</div>
      <div className="mt-1 text-xl font-bold">{valor}</div>
      <div className="mt-1 text-sm text-black/55">{detalle}</div>
    </div>
  );
}
