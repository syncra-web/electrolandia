"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ESTADOS, CARGADORES } from "@/lib/config";
import { horaToNum, horaLabel } from "@/lib/availability";
import type { Reserva } from "@/lib/types";

const COLOR_ESTADO: Record<string, string> = {
  Confirmada: "bg-[var(--verde)]/15 text-[var(--verde-dark)]",
  Finalizada: "bg-blue-100 text-blue-700",
  "No asistió": "bg-black/10 text-black/60",
  Cancelada: "bg-red-100 text-red-700",
};

export default function AdminPage() {
  const router = useRouter();
  const [filtro, setFiltro] = useState<"hoy" | "proximas">("hoy");
  const [reservas, setReservas] = useState<Reserva[]>([]);
  const [cargando, setCargando] = useState(true);

  const cargar = useCallback(async () => {
    setCargando(true);
    const res = await fetch(`/api/admin/reservas?filtro=${filtro}`);
    if (res.ok) {
      const d = await res.json();
      setReservas(d.reservas ?? []);
    }
    setCargando(false);
  }, [filtro]);

  useEffect(() => {
    cargar();
  }, [cargar]);

  async function cambiarEstado(id: string, estado: string) {
    await fetch(`/api/admin/reservas?id=${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ estado }),
    });
    cargar();
  }

  async function salir() {
    await fetch("/api/admin/login", { method: "DELETE" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <main className="min-h-screen">
      <header className="bg-[var(--ink)] text-white">
        <div className="mx-auto flex max-w-4xl items-center justify-between px-5 py-4">
          <span className="font-display font-bold">Panel · Electrolandia</span>
          <button onClick={salir} className="text-sm text-white/70 hover:text-white">
            Cerrar sesión
          </button>
        </div>
      </header>

      <div className="mx-auto max-w-4xl px-5 py-6">
        <div className="flex gap-2">
          {(["hoy", "proximas"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFiltro(f)}
              className={`rounded-full px-4 py-2 text-sm font-medium transition ${
                filtro === f ? "bg-[var(--ink)] text-white" : "bg-black/5 hover:bg-black/10"
              }`}
            >
              {f === "hoy" ? "Reservas de hoy" : "Próximas reservas"}
            </button>
          ))}
          <button onClick={cargar} className="ml-auto rounded-full px-4 py-2 text-sm text-black/55 hover:text-black">
            ↻ Actualizar
          </button>
        </div>

        {cargando ? (
          <p className="mt-8 text-sm text-black/50">Cargando…</p>
        ) : reservas.length === 0 ? (
          <p className="mt-8 text-sm text-black/50">No hay reservas para mostrar.</p>
        ) : (
          <div className="mt-5 space-y-3">
            {reservas.map((r) => {
              const cargador = CARGADORES.find((c) => c.id === r.cargador);
              const ini = horaToNum(r.hora_inicio);
              const fin = horaToNum(r.hora_fin);
              return (
                <div key={r.id} className="rounded-2xl border border-black/5 bg-white p-4">
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <div className="font-semibold">{r.nombre}</div>
                      <div className="text-sm text-black/55">
                        {r.fecha} · {horaLabel(ini)}–{horaLabel(fin === 24 ? 0 : fin)} ({fin - ini}h) ·{" "}
                        {cargador?.nombre ?? r.cargador}
                      </div>
                    </div>
                    <span className={`rounded-full px-3 py-1 text-xs font-semibold ${COLOR_ESTADO[r.estado] ?? ""}`}>
                      {r.estado}
                    </span>
                  </div>

                  <div className="mt-3 grid gap-1 text-sm text-black/70 sm:grid-cols-2">
                    <span>📱 {r.whatsapp}</span>
                    <span>✉️ {r.correo}</span>
                    <span>🚗 {r.marca} {r.modelo} · {r.placa}</span>
                    <span>🔌 {r.conector}</span>
                    {r.observaciones && <span className="sm:col-span-2">📝 {r.observaciones}</span>}
                  </div>

                  <div className="mt-3 flex flex-wrap gap-2 border-t border-black/5 pt-3">
                    {ESTADOS.map((e) => (
                      <button
                        key={e}
                        onClick={() => cambiarEstado(r.id, e)}
                        disabled={r.estado === e}
                        className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                          r.estado === e
                            ? "cursor-default bg-black/5 text-black/40"
                            : "bg-black/5 hover:bg-black/15"
                        }`}
                      >
                        {e}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </main>
  );
}
