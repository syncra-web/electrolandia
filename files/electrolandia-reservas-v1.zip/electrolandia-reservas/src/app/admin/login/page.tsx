"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLogin() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [cargando, setCargando] = useState(false);

  async function entrar() {
    setError("");
    setCargando(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (res.ok) {
        router.push("/admin");
        router.refresh();
      } else {
        const d = await res.json();
        setError(d.error || "Clave incorrecta");
      }
    } catch {
      setError("Error de conexión");
    } finally {
      setCargando(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[var(--ink)] px-5">
      <div className="w-full max-w-sm rounded-2xl bg-white p-6">
        <h1 className="font-display text-2xl font-bold">Panel · Electrolandia</h1>
        <p className="mt-1 text-sm text-black/55">Ingresa la clave de administrador.</p>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && entrar()}
          placeholder="Clave"
          className="mt-4 w-full rounded-xl border border-black/15 px-3 py-2.5 outline-none focus:border-[var(--verde)]"
        />
        {error && <p className="mt-3 text-sm text-red-600">{error}</p>}
        <button
          onClick={entrar}
          disabled={cargando}
          className="mt-4 w-full rounded-2xl bg-[var(--verde)] px-6 py-3 font-semibold text-[var(--ink)] transition hover:bg-[var(--verde-dark)] hover:text-white disabled:opacity-60"
        >
          {cargando ? "Entrando…" : "Entrar"}
        </button>
      </div>
    </main>
  );
}
