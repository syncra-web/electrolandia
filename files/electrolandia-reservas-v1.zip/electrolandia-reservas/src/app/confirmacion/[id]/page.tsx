import Link from "next/link";
import { supabaseAdmin } from "@/lib/supabase";
import { NEGOCIO, CARGADORES, ADAPTADORES } from "@/lib/config";
import { horaToNum, horaLabel } from "@/lib/availability";
import type { Reserva } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function ConfirmacionPage({ params }: { params: { id: string } }) {
  const db = supabaseAdmin();
  const { data } = await db.from("reservas").select("*").eq("id", params.id).single();
  const r = data as Reserva | null;

  if (!r) {
    return (
      <main className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center px-5 text-center">
        <p className="text-lg font-semibold">No encontramos esta reserva.</p>
        <Link href="/reservar" className="mt-4 rounded-2xl bg-[var(--ink)] px-6 py-3 text-white">
          Hacer una reserva
        </Link>
      </main>
    );
  }

  const cargador = CARGADORES.find((c) => c.id === r.cargador);
  const ini = horaToNum(r.hora_inicio);
  const fin = horaToNum(r.hora_fin);

  return (
    <main className="min-h-screen">
      <section className="bg-[var(--ink)] text-white">
        <div className="mx-auto max-w-md px-5 py-12 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-[var(--verde)] text-3xl text-[var(--ink)]">
            ✓
          </div>
          <h1 className="mt-5 font-display text-3xl font-extrabold">¡Reserva confirmada!</h1>
          <p className="mt-2 text-white/70">Te esperamos. Aquí están tus datos.</p>
        </div>
      </section>

      <div className="mx-auto max-w-md space-y-4 px-5 py-8">
        <div className="rounded-2xl border border-black/5 bg-white p-5">
          <Row label="Reserva" value={`#${r.id.slice(0, 8).toUpperCase()}`} />
          <Row label="Fecha" value={r.fecha} />
          <Row
            label="Horario"
            value={`${horaLabel(ini)} → ${horaLabel(fin === 24 ? 0 : fin)} (${fin - ini} h)`}
          />
          <Row label="Cargador" value={`${cargador?.nombre ?? r.cargador}`} />
          <Row label="Vehículo" value={`${r.marca} ${r.modelo} · ${r.placa}`} />
          <Row label="Conector" value={r.conector} last />
        </div>

        <a
          href={NEGOCIO.mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="block rounded-2xl bg-[var(--verde)] px-6 py-4 text-center font-semibold text-[var(--ink)] transition hover:bg-[var(--verde-dark)] hover:text-white"
        >
          📍 Cómo llegar (Google Maps)
        </a>

        <div className="rounded-2xl border border-black/5 bg-white p-5 text-sm">
          <p className="font-semibold">Dirección</p>
          <p className="mt-1 text-black/65">{cargador?.direccion}</p>

          <p className="mt-4 font-semibold">Al llegar</p>
          <p className="mt-1 text-black/65">
            Conecta tu vehículo y la carga inicia automáticamente. Nuestro cargador es J1772 (Tipo
            1); si tu carro usa {ADAPTADORES.join(" o ")}, te facilitamos el adaptador sin costo.
          </p>

          <p className="mt-4 font-semibold">¿Dudas?</p>
          <p className="mt-1 text-black/65">
            WhatsApp {NEGOCIO.contacto.whatsapp} · {NEGOCIO.contacto.correo}
          </p>
        </div>

        <Link href="/" className="block py-2 text-center text-sm text-black/55 hover:text-black">
          Volver al inicio
        </Link>
      </div>
    </main>
  );
}

function Row({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <div className={`flex items-center justify-between py-2.5 ${last ? "" : "border-b border-black/5"}`}>
      <span className="text-sm text-black/50">{label}</span>
      <span className="text-right text-sm font-semibold">{value}</span>
    </div>
  );
}
