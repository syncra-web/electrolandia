"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { CARGADORES, CONECTORES, MARCAS, tarifaPorHora, formatoCOP } from "@/lib/config";
import { horaLabel, maxFinDesde } from "@/lib/availability";
import type { DisponibilidadRespuesta } from "@/lib/types";

function hoyISO(): string {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

export default function ReservarPage() {
  const router = useRouter();
  const [cargador, setCargador] = useState<string>("");
  const [fecha, setFecha] = useState<string>("");
  const [disp, setDisp] = useState<DisponibilidadRespuesta | null>(null);
  const [cargando, setCargando] = useState(false);

  const [inicio, setInicio] = useState<number | null>(null);
  const [fin, setFin] = useState<number | null>(null);

  const [form, setForm] = useState({
    nombre: "",
    whatsapp: "",
    correo: "",
    placa: "",
    marca: "",
    modelo: "",
    conector: "" as string,
    observaciones: "",
    terminos: false,
  });
  const [enviando, setEnviando] = useState(false);
  const [error, setError] = useState<string>("");

  // Cargar disponibilidad cuando hay cargador + fecha
  useEffect(() => {
    if (!cargador || !fecha) return;
    setCargando(true);
    setDisp(null);
    setInicio(null);
    setFin(null);
    fetch(`/api/disponibilidad?fecha=${fecha}`)
      .then((r) => r.json())
      .then((data: DisponibilidadRespuesta) => setDisp(data))
      .catch(() => setError("No se pudo cargar la disponibilidad."))
      .finally(() => setCargando(false));
  }, [cargador, fecha]);

  const horasCargador = disp?.cargadores.find((c) => c.cargador === cargador)?.horas ?? [];
  const libresBool = horasCargador.map((h) => h.libre);
  const maxFin = inicio !== null ? maxFinDesde(inicio, libresBool) : null;

  function elegirInicio(h: number) {
    setInicio(h);
    setFin(null);
    setError("");
  }

  async function enviar() {
    setError("");
    if (!cargador || !fecha || inicio === null || fin === null) {
      setError("Completa cargador, fecha y horario.");
      return;
    }
    if (!form.terminos) {
      setError("Debes aceptar los términos.");
      return;
    }
    setEnviando(true);
    try {
      const res = await fetch("/api/reservas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cargador,
          nombre: form.nombre,
          whatsapp: form.whatsapp,
          correo: form.correo,
          placa: form.placa,
          marca: form.marca,
          modelo: form.modelo,
          conector: form.conector,
          fecha,
          hora_inicio: inicio,
          hora_fin: fin,
          observaciones: form.observaciones,
          terminos: form.terminos,
        }),
      });
      const data = await res.json();
      if (res.status === 201 && data.id) {
        router.push(`/confirmacion/${data.id}`);
        return;
      }
      if (res.status === 409) {
        setError(data.error || "Ese horario acaba de ocuparse. Elige otro.");
        // refrescar disponibilidad
        const r = await fetch(`/api/disponibilidad?fecha=${fecha}`);
        setDisp(await r.json());
        setInicio(null);
        setFin(null);
      } else {
        setError(data.error || "No se pudo crear la reserva. Revisa los datos.");
      }
    } catch {
      setError("Error de conexión. Intenta de nuevo.");
    } finally {
      setEnviando(false);
    }
  }

  const set =
    (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
      const t = e.target as HTMLInputElement;
      const value = t.type === "checkbox" ? t.checked : t.value;
      setForm((f) => ({ ...f, [k]: value }));
    };

  const listo = cargador && fecha && inicio !== null && fin !== null;

  return (
    <main className="min-h-screen">
      <header className="bg-[var(--ink)] text-white">
        <div className="mx-auto flex max-w-2xl items-center justify-between px-5 py-4">
          <Link href="/" className="text-sm text-white/70 hover:text-white">← Inicio</Link>
          <span className="font-display font-bold">Reservar carga</span>
        </div>
      </header>

      <div className="mx-auto max-w-2xl space-y-6 px-5 py-8">
        {/* PASO 1: cargador + fecha */}
        <section className="rounded-2xl border border-black/5 bg-white p-5">
          <h2 className="font-display text-lg font-bold">1. Cargador y fecha</h2>
          <div className="mt-4 grid grid-cols-2 gap-3">
            {CARGADORES.map((c) => (
              <button
                key={c.id}
                onClick={() => setCargador(c.id)}
                className={`rounded-xl border p-3 text-left transition ${
                  cargador === c.id
                    ? "border-[var(--verde)] bg-[var(--verde)]/10"
                    : "border-black/10 hover:border-black/30"
                }`}
              >
                <div className="font-semibold">{c.nombre}</div>
                <div className="text-xs text-black/55">{c.direccion}</div>
              </button>
            ))}
          </div>
          <label className="mt-4 block text-sm font-medium text-black/70">Fecha</label>
          <input
            type="date"
            min={hoyISO()}
            value={fecha}
            onChange={(e) => setFecha(e.target.value)}
            className="mt-1 w-full rounded-xl border border-black/15 px-3 py-2.5 outline-none focus:border-[var(--verde)]"
          />
        </section>

        {/* PASO 2: horario */}
        {cargador && fecha && (
          <section className="rounded-2xl border border-black/5 bg-white p-5">
            <h2 className="font-display text-lg font-bold">2. Horario</h2>
            <p className="mt-1 text-sm text-black/55">
              Es carga AC (~11 kW): elige cuántas horas dejarás tu vehículo. Verde = libre.
            </p>

            {cargando && <p className="mt-4 text-sm text-black/50">Cargando disponibilidad…</p>}

            {!cargando && disp && (
              <>
                <p className="mt-4 text-sm font-medium text-black/70">Hora de inicio</p>
                <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-6">
                  {horasCargador.map((h) => (
                    <button
                      key={h.hora}
                      disabled={!h.libre}
                      onClick={() => elegirInicio(h.hora)}
                      className={`rounded-lg px-2 py-2 text-sm font-medium transition ${
                        inicio === h.hora
                          ? "bg-[var(--ink)] text-white"
                          : h.libre
                          ? "bg-[var(--verde)]/15 text-[var(--verde-dark)] hover:bg-[var(--verde)]/30"
                          : "cursor-not-allowed bg-black/5 text-black/30 line-through"
                      }`}
                    >
                      {h.label}
                    </button>
                  ))}
                </div>

                {inicio !== null && maxFin !== null && (
                  <>
                    <p className="mt-5 text-sm font-medium text-black/70">¿Hasta qué hora?</p>
                    <div className="mt-2 flex flex-wrap gap-2">
                      {Array.from({ length: maxFin - inicio }, (_, i) => inicio + i + 1).map((hf) => (
                        <button
                          key={hf}
                          onClick={() => setFin(hf)}
                          className={`rounded-lg px-3 py-2 text-sm font-medium transition ${
                            fin === hf
                              ? "bg-[var(--ink)] text-white"
                              : "bg-black/5 hover:bg-black/10"
                          }`}
                        >
                          {horaLabel(hf === 24 ? 0 : hf)}
                          <span className="ml-1 text-xs opacity-60">({hf - inicio}h)</span>
                        </button>
                      ))}
                    </div>
                  </>
                )}

                {listo && (
                  <div className="mt-5 rounded-xl bg-[var(--crema)] p-4 text-sm">
                    <div className="font-semibold">
                      {CARGADORES.find((c) => c.id === cargador)?.nombre} · {fecha}
                    </div>
                    <div className="text-black/70">
                      {horaLabel(inicio!)} → {horaLabel(fin === 24 ? 0 : fin!)} ({fin! - inicio!} hora
                      {fin! - inicio! > 1 ? "s" : ""})
                    </div>
                    <div className="mt-1 text-black/55">
                      Tarifa de inicio: {formatoCOP(tarifaPorHora(inicio!))}/kWh · pago en el sitio.
                    </div>
                  </div>
                )}
              </>
            )}
          </section>
        )}

        {/* PASO 3: datos */}
        {listo && (
          <section className="rounded-2xl border border-black/5 bg-white p-5">
            <h2 className="font-display text-lg font-bold">3. Tus datos</h2>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Field label="Nombre completo">
                <input value={form.nombre} onChange={set("nombre")} className={inputCls} placeholder="Ej. Ana Gómez" />
              </Field>
              <Field label="WhatsApp">
                <input value={form.whatsapp} onChange={set("whatsapp")} inputMode="tel" className={inputCls} placeholder="Ej. 300 123 4567" />
              </Field>
              <Field label="Correo electrónico">
                <input value={form.correo} onChange={set("correo")} inputMode="email" className={inputCls} placeholder="tucorreo@email.com" />
              </Field>
              <Field label="Placa del vehículo">
                <input value={form.placa} onChange={set("placa")} className={`${inputCls} uppercase`} placeholder="ABC123" />
              </Field>
              <Field label="Marca">
                <input list="marcas" value={form.marca} onChange={set("marca")} className={inputCls} placeholder="Ej. BYD" />
                <datalist id="marcas">
                  {MARCAS.map((m) => (
                    <option key={m} value={m} />
                  ))}
                </datalist>
              </Field>
              <Field label="Modelo">
                <input value={form.modelo} onChange={set("modelo")} className={inputCls} placeholder="Ej. Dolphin" />
              </Field>
              <Field label="Tipo de conector">
                <select value={form.conector} onChange={set("conector")} className={inputCls}>
                  <option value="">Selecciona…</option>
                  {CONECTORES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label="Observaciones (opcional)">
                <input value={form.observaciones} onChange={set("observaciones")} className={inputCls} placeholder="Algo que debamos saber" />
              </Field>
            </div>

            <label className="mt-4 flex items-start gap-3 text-sm text-black/70">
              <input type="checkbox" checked={form.terminos} onChange={set("terminos")} className="mt-1 h-4 w-4" />
              <span>
                Acepto llegar puntual, usar el cargador de forma responsable y entender que la carga
                es AC (~11 kW) y toma varias horas.
              </span>
            </label>

            {error && (
              <p className="mt-4 rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>
            )}

            <button
              onClick={enviar}
              disabled={enviando}
              className="mt-5 w-full rounded-2xl bg-[var(--verde)] px-6 py-4 text-base font-semibold text-[var(--ink)] transition hover:bg-[var(--verde-dark)] hover:text-white disabled:opacity-60"
            >
              {enviando ? "Confirmando…" : "Confirmar reserva"}
            </button>
          </section>
        )}

        {error && !listo && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{error}</p>
        )}
      </div>
    </main>
  );
}

const inputCls =
  "w-full rounded-xl border border-black/15 px-3 py-2.5 outline-none focus:border-[var(--verde)]";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-black/70">{label}</span>
      {children}
    </label>
  );
}
